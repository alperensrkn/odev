<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Bundle the official logo as a local image import shared by all logo displays so asset delivery is independent of the hosting domain.
- Keep legal documents in dedicated content routes using the shared LegalPage shell so each document has its own URL and metadata.
- Accept inquiries only through a validated, write-only server function with private storage, retry deduplication, and no public read grants; email sending requires a verified domain before wiring.
- Use progressive IntersectionObserver reveals so content stays visible without JavaScript and reduced-motion preferences are respected.
