CREATE TABLE public.partner_inquiries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 submission_id uuid NOT NULL UNIQUE,
 name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 100),
 company text NOT NULL CHECK (char_length(company) BETWEEN 1 AND 120),
 email text NOT NULL CHECK (char_length(email) BETWEEN 3 AND 255),
 message text NOT NULL CHECK (char_length(message) BETWEEN 1 AND 1000),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.partner_inquiries TO service_role;
ALTER TABLE public.partner_inquiries ENABLE ROW LEVEL SECURITY;
CREATE INDEX partner_inquiries_created_at_idx ON public.partner_inquiries (created_at DESC);