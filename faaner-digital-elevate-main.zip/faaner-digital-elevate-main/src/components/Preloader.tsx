import { useEffect, useState } from "react";
import logo from "@/assets/faaner-logo-mark.png";

export function Preloader() {
  const [gone, setGone] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setGone(true), 2500);
    return () => clearTimeout(t);
  }, []);

  if (gone) return null;

  return (
    <div
      className="veil-out pointer-events-none fixed inset-0 z-100 flex items-center justify-center bg-intro"
    >
      <img
        src={logo}
        alt="Faaner LLC"
        className="logo-pop relative w-[70vw] max-w-lg object-contain"
        
        loading="eager"
        decoding="async"
      />
    </div>
  );
}
