import { createServerFn } from "@tanstack/react-start";
import { inquirySubmissionSchema } from "./inquiry-schema";

// Public write-only intake. Never accepts a table, recipient, or read request.
export const submitInquiry = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => inquirySubmissionSchema.parse(input))
  .handler(async ({ data }) => {
    if (data.website) throw new Error("Unable to submit this inquiry.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing, error: existingError } = await supabaseAdmin
      .from("partner_inquiries").select("id").eq("submission_id", data.submissionId).maybeSingle();
    if (existingError) throw new Error("Unable to save your inquiry. Please try again.");
    if (existing) return { saved: true };
    const { count, error: countError } = await supabaseAdmin.from("partner_inquiries")
      .select("id", { count: "exact", head: true })
      .eq("email", data.email).gte("created_at", new Date(Date.now() - 60_000).toISOString());
    if (countError) throw new Error("Unable to save your inquiry. Please try again.");
    if ((count ?? 0) >= 3) throw new Error("Please wait a minute before submitting another inquiry.");
    const { error } = await supabaseAdmin.from("partner_inquiries").insert({
      submission_id: data.submissionId, name: data.name, company: data.company,
      email: data.email, message: data.message,
    });
    if (error && error.code !== "23505") throw new Error("Unable to save your inquiry. Please try again.");
    return { saved: true };
  });