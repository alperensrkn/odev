import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { FaanerLogo } from "./FaanerLogo";
import { CompanyDetails } from "./CompanyDetails";
import { Button } from "./ui/button";

export function LegalPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-6">
          <Link to="/" aria-label="Faaner LLC home"><FaanerLogo className="h-8 max-w-[50vw]" /></Link>
          <Button asChild variant="outline"><Link to="/">Back to home</Link></Button>
        </div>
      </header>
      <main className="legal-copy mx-auto max-w-3xl px-5 py-12 sm:py-16">
        <p className="text-xs font-semibold uppercase text-navy">Faaner LLC · Wyoming, USA</p>
        <h1 className="mt-4 text-3xl font-bold sm:text-5xl">{title}</h1>
        <p className="mt-4 text-sm text-muted-foreground">Effective November 19, 2026</p>
        <div className="mt-10 space-y-8">{children}</div>
      </main>
      <footer className="border-t border-border py-8">
        <div className="mx-auto flex max-w-5xl flex-col justify-between gap-6 px-5 sm:flex-row">
          <CompanyDetails />
          <nav className="flex gap-5 text-sm"><Link to="/privacy">Privacy Policy</Link><Link to="/terms">Terms of Service</Link></nav>
        </div>
      </footer>
    </div>
  );
}