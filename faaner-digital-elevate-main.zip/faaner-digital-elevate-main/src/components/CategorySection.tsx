import { useState } from "react";
import {
  ArrowUpRight,
  Boxes,
  Briefcase,
  Cpu,
  Dumbbell,
  Globe2,
  Home,
  Sparkles,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { TiltCard } from "./TiltCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import catTech from "@/assets/cat-tech.jpg";
import catHome from "@/assets/cat-home.jpg";
import catSports from "@/assets/cat-sports.jpg";
import catOffice from "@/assets/cat-office.jpg";
import catBeauty from "@/assets/cat-beauty.jpg";
import catUnlimited from "@/assets/cat-unlimited.jpg";

type Category = {
  icon: LucideIcon;
  title: string;
  copy: string;
  image: string;
  tagline: string;
  detail: string;
  points: { label: string; copy: string }[];
};

const categories: Category[] = [
  {
    icon: Cpu,
    title: "Consumer Tech & Accessories",
    copy: "Audio, wearables, charging and smart-home accessories managed with tight catalog control.",
    image: catTech,
    tagline: "Audio, wearables, charging & smart home",
    detail:
      "We manage fast-moving tech catalogs where variation data, compatibility details and firmware revisions change constantly. Every SKU is mapped to authorized supply, enriched with accurate specifications and monitored for listing hijacks and unauthorized resellers.",
    points: [
      {
        label: "Catalog management",
        copy: "Variation-level SKU mapping, spec sheets, A+ content alignment and image compliance across every channel we operate.",
      },
      {
        label: "Inventory control",
        copy: "Velocity-based replenishment with launch-cycle forecasting so hero SKUs never go out of stock during peak demand.",
      },
      {
        label: "Brand protection",
        copy: "Continuous MAP monitoring, authorized-only sourcing and rapid escalation on counterfeit or diverted inventory.",
      },
    ],
  },
  {
    icon: Home,
    title: "Home & Kitchen",
    copy: "Everyday essentials and premium kitchenware built for high-velocity marketplace demand.",
    image: catHome,
    tagline: "Cookware, small appliances & everyday essentials",
    detail:
      "Home and kitchen demand is seasonal and bundle-driven. We build clean parent-child catalog structures, protect premium price positioning and keep replenishment tight through gifting and holiday peaks.",
    points: [
      {
        label: "Catalog management",
        copy: "Bundle and set architecture, material and care details, and lifestyle imagery that matches brand guidelines.",
      },
      {
        label: "Inventory control",
        copy: "Seasonal buy plans with prepped inbound shipments so Q4 and gifting windows are covered weeks ahead.",
      },
      {
        label: "Distribution strategy",
        copy: "Channel-by-channel assortment planning that avoids internal price collisions with your own D2C store.",
      },
    ],
  },
  {
    icon: Dumbbell,
    title: "Sports & Outdoors",
    copy: "Training gear, recovery and outdoor equipment with seasonal demand planning.",
    image: catSports,
    tagline: "Training, recovery & outdoor equipment",
    detail:
      "From strength equipment to recovery tools and outdoor gear, we handle heavy and oversized logistics while keeping sizing, spec and safety information exact on every listing.",
    points: [
      {
        label: "Catalog management",
        copy: "Accurate sizing charts, weight and dimension data, and compliance documentation where categories require it.",
      },
      {
        label: "Inventory control",
        copy: "Seasonality models for New Year, spring and outdoor peaks, with oversized freight handled end to end.",
      },
      {
        label: "Brand protection",
        copy: "Authorized-only distribution with policy enforcement against grey-market and unauthorized listings.",
      },
    ],
  },
  {
    icon: Briefcase,
    title: "Office & Workspace",
    copy: "Desk setups, ergonomics and supplies for hybrid work and B2B replenishment.",
    image: catOffice,
    tagline: "Ergonomics, desk setups & B2B supplies",
    detail:
      "Office and workspace lines mix consumer purchases with recurring B2B replenishment. We structure catalogs for both, with case-pack logic and consistent pricing across retail and business buyer channels.",
    points: [
      {
        label: "Catalog management",
        copy: "Case-pack and multi-pack structures, technical spec accuracy and business-buyer-ready content.",
      },
      {
        label: "Inventory control",
        copy: "Steady replenishment cadence tuned to back-to-work and fiscal-year purchasing cycles.",
      },
      {
        label: "Distribution strategy",
        copy: "Coordinated retail and B2B assortments that protect your MAP floor on every channel.",
      },
    ],
  },
  {
    icon: Sparkles,
    title: "Beauty & Personal Care",
    copy: "Authenticity-first handling for skincare, grooming and personal care lines.",
    image: catBeauty,
    tagline: "Skincare, grooming & personal care",
    detail:
      "Beauty is the category where authenticity and handling matter most. We source only through authorized channels, keep full lot traceability and store product in conditions that protect formulation integrity.",
    points: [
      {
        label: "Catalog management",
        copy: "Ingredient lists, claims compliance and batch-accurate listing content reviewed before every launch.",
      },
      {
        label: "Inventory control",
        copy: "Batch and expiry tracking with first-expiry-first-out rotation and controlled storage conditions.",
      },
      {
        label: "Brand protection",
        copy: "Zero tolerance on diverted or repackaged goods, with documented chain of custody on every purchase order.",
      },
    ],
  },
];

const unlimited: Category = {
  icon: Globe2,
  title: "Unlimited Category Reach & Custom Sourcing",
  copy: "We are not limited to five verticals. With a brand partnership in place, we source, list and scale products in any category.",
  image: catUnlimited,
  tagline: "Any brand, any category, globally",
  detail:
    "If there's a brand partnership, we have the infrastructure to manage, list, and scale products in any category globally. Our authorized brand and distributor relationships let us open new verticals on request — from niche industrial lines to mainstream consumer goods.",
  points: [
    {
      label: "Custom sourcing",
      copy: "Tell us the brand or portfolio and we build the sourcing, compliance and listing plan around it — no category limits.",
    },
    {
      label: "Scalable operations",
      copy: "The same catalog, inventory and reporting infrastructure applies to every new vertical we take on.",
    },
    {
      label: "Global distribution",
      copy: "Marketplace and direct digital channels across regions, always inside your pricing and territory policies.",
    },
  ],
};

export function CategorySection() {
  const [active, setActive] = useState<Category | null>(null);

  const goToForm = () => {
    setActive(null);
    setTimeout(() => {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 180);
  };

  return (
    <section data-reveal id="categories" className="relative py-14 sm:py-20">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="max-w-3xl">
          <span className="text-xs font-semibold tracking-[0.18em] text-navy uppercase">
            Retail categories
          </span>
          <h2 className="mt-4 text-3xl font-extrabold sm:text-5xl">
            Core retail categories. Unlimited sourcing possibilities.
          </h2>
          <p className="mt-4 text-muted-foreground">
            These categories are a starting point, not a limit: through our authorized brand and distributor partnerships we can
            source, list and sell any product in any category.
          </p>
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c) => (
            <TiltCard key={c.title} className="group h-full rounded-3xl">
              <Button variant="ghost"
                type="button"
                onClick={() => setActive(c)}
                aria-label={`View details for ${c.title}`}
                className="h-auto min-h-72 items-start justify-start whitespace-normal hover:bg-card flex h-full w-full flex-col rounded-3xl border border-border/70 bg-card p-7 text-left shadow-float focus-visible:ring-2 focus-visible:ring-navy focus-visible:outline-none"
              >
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-tint text-navy transition-colors duration-300 group-hover:bg-navy group-hover:text-navy-foreground">
                  <c.icon className="h-5.5 w-5.5" />
                </span>
                <h3 className="mt-6 text-lg font-bold">{c.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c.copy}</p>
                <span className="mt-6 inline-flex items-center gap-1.5 text-xs font-semibold tracking-[0.12em] text-navy uppercase">
                  Partner in this vertical <ArrowUpRight className="h-3.5 w-3.5" />
                </span>
              </Button>
            </TiltCard>
          ))}

          <TiltCard className="group h-full rounded-3xl" max={6}>
            <Button variant="ghost"
              type="button"
              onClick={() => setActive(unlimited)}
              aria-label="View details for unlimited category reach and custom sourcing"
              className="h-auto min-h-72 items-start justify-start whitespace-normal hover:bg-primary hover:text-primary-foreground flex h-full w-full flex-col rounded-3xl bg-primary p-7 text-left text-primary-foreground shadow-lift focus-visible:ring-2 focus-visible:ring-navy focus-visible:outline-none"
            >
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-background/15 text-primary-foreground">
                <Boxes className="h-5.5 w-5.5" />
              </span>
              <h3 className="mt-6 text-lg font-bold text-primary-foreground">{unlimited.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-primary-foreground/80">
                If there's a brand partnership, we have the infrastructure to manage, list, and scale
                products in any category globally.
              </p>
              <span className="mt-6 inline-flex items-center gap-1.5 text-xs font-semibold tracking-[0.12em] uppercase">
                Explore custom sourcing <ArrowUpRight className="h-3.5 w-3.5" />
              </span>
            </Button>
          </TiltCard>
        </div>
      </div>

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-h-[90vh] gap-0 overflow-y-auto rounded-3xl border-border/70 p-0 sm:max-w-3xl">
          {active && (
            <>
              <div className="relative">
                <img
                  src={active.image}
                  alt={`${active.title} product showcase`}
                  loading="lazy"
                  width={1280}
                  height={800}
                  className="h-52 w-full object-cover sm:h-64"
                />
                <div className="pointer-events-none absolute inset-0 bg-linear-to-t from-card via-card/10 to-transparent" />
              </div>

              <div className="px-7 pb-8 sm:px-10">
                <DialogHeader className="text-left">
                  <span className="text-xs font-semibold tracking-[0.18em] text-navy uppercase">
                    {active.tagline}
                  </span>
                  <DialogTitle className="mt-2 text-2xl font-extrabold sm:text-3xl">
                    {active.title}
                  </DialogTitle>
                  <DialogDescription className="mt-3 text-sm leading-relaxed sm:text-base">
                    {active.detail}
                  </DialogDescription>
                </DialogHeader>

                <div className="mt-7 space-y-4">
                  {active.points.map((p) => (
                    <div
                      key={p.label}
                      className="rounded-2xl border border-border/70 bg-sky-tint/60 p-5 shadow-float"
                    >
                      <h4 className="text-sm font-bold">{p.label}</h4>
                      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.copy}</p>
                    </div>
                  ))}
                </div>

                <Button variant="ghost"
                  type="button"
                  onClick={goToForm}
                  className="h-auto whitespace-normal group mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-semibold text-primary-foreground shadow-lift transition-all duration-300 hover:-translate-y-0.5 hover:bg-navy sm:w-auto"
                >
                  Partner With Us in This Vertical
                  <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
