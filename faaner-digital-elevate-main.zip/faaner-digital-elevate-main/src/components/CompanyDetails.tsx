export function CompanyDetails() {
  return (
    <address className="not-italic text-sm leading-7 text-muted-foreground">
      <strong className="block font-semibold text-foreground">Faaner LLC</strong>
      <span className="block">Registered in Wyoming, USA</span>
      <a href="mailto:sales@faanerllc.com" className="break-all hover:text-navy">sales@faanerllc.com</a>
    </address>
  );
}