import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowUpRight,
  BadgeCheck,
  Headphones,
  Mail,
  MapPin,
  ShieldCheck,
  Truck,
} from "lucide-react";
import { CompanyDetails } from "@/components/CompanyDetails";
import { ScrollReveals } from "@/components/ScrollReveals";
import heroProducts from "@/assets/cat-unlimited.jpg";
import { Preloader } from "@/components/Preloader";
import { SiteHeader } from "@/components/SiteHeader";
import { TiltCard } from "@/components/TiltCard";
import { CategorySection } from "@/components/CategorySection";
import { PartnerForm } from "@/components/PartnerForm";
import { FaanerLogo } from "@/components/FaanerLogo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Faaner LLC — E-Commerce Retail & Distribution Partner" },
      {
        name: "description",
        content:
          "Faaner LLC is a registered US e-commerce retailer in Wyoming connecting quality brands with digital shoppers through MAP-compliant distribution.",
      },
      { property: "og:title", content: "Faaner LLC — E-Commerce Retail & Distribution Partner" },
      {
        property: "og:description",
        content:
          "A registered US e-commerce business connecting quality brands with digital shoppers. Partner with Faaner LLC.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});


const values = [
  {
    icon: BadgeCheck,
    title: "100% MAP Compliance",
    copy: "Pricing policies are honoured across every channel we operate, monitored continuously.",
  },
  {
    icon: ShieldCheck,
    title: "Brand Integrity Protection",
    copy: "Authorized-only sourcing, accurate listings and zero tolerance for unauthorized diversion.",
  },
  {
    icon: Truck,
    title: "Swift Operations & Logistics",
    copy: "Fast purchase orders, prepped inbound shipments and reliable inventory turnover.",
  },
  {
    icon: Headphones,
    title: "Dedicated Partner Support",
    copy: "One accountable point of contact for forecasting, reporting and escalations.",
  },
];

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Preloader />
      <ScrollReveals />
      <SiteHeader />

      {/* Hero */}
      <section id="home" className="relative overflow-hidden pt-32 pb-14 sm:pt-36 sm:pb-16">
        <img src={heroProducts} alt="" aria-hidden="true" className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-40" />
        <div className="hero-wash pointer-events-none absolute inset-0" />
        <div className="relative mx-auto max-w-5xl px-5 text-center lg:px-8">
          <p
            className="rise-in glass-panel mx-auto inline-flex items-center gap-2 rounded-full border border-border/70 px-4 py-1.5 text-xs font-semibold tracking-[0.16em] text-navy uppercase"
            style={{ animationDelay: "2.5s" }}
          >
            <MapPin className="h-3.5 w-3.5" /> Registered in Wyoming, USA
          </p>
          <h1
            className="rise-in mt-7 text-4xl leading-[1.05] font-extrabold text-foreground sm:text-6xl lg:text-7xl"
            style={{ animationDelay: "2.62s" }}
          >
            Faaner LLC — US-Registered E-Commerce Retail &amp; Distribution Partner
          </h1>
          <p
            className="rise-in mx-auto mt-7 max-w-2xl text-base text-muted-foreground sm:text-lg"
            style={{ animationDelay: "2.74s" }}
          >
            A registered US e-commerce business connecting quality brands with digital shoppers.
          </p>
          <div
            className="rise-in mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row"
            style={{ animationDelay: "2.86s" }}
          >
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-semibold text-primary-foreground shadow-lift transition-all duration-300 hover:-translate-y-1 hover:bg-navy"
            >
              Become a Partner
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <a
              href="#categories"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-7 py-4 text-sm font-semibold text-foreground backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:border-navy hover:text-navy"
            >
              Explore retail categories
            </a>
          </div>

          <div
            className="rise-in mx-auto mt-10 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4"
            style={{ animationDelay: "3s" }}
          >
            {[
              ["Any", "Category reach"],
              ["100%", "MAP compliance"],
              ["Direct", "Partner contact"],
              ["US", "Registered entity"],
            ].map(([big, small]) => (
              <div
                key={small}
                className="rounded-2xl border border-border/70 bg-card/80 px-4 py-5 shadow-float backdrop-blur"
              >
                <div className="font-display text-2xl font-extrabold text-foreground">{big}</div>
                <div className="mt-1 text-xs text-muted-foreground">{small}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <CategorySection />


      {/* Partnerships / value props */}
      <section data-reveal id="partnerships" className="relative overflow-hidden bg-sky-tint py-14 sm:py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold tracking-[0.18em] text-navy uppercase">
              Brand protection
            </span>
            <h2 className="mt-4 text-3xl font-extrabold sm:text-5xl">
              Commitments we make to every brand we carry
            </h2>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {values.map((v) => (
              <div
                key={v.title}
                 data-reveal
                className="flex gap-5 rounded-3xl border border-border/60 bg-card/85 p-7 shadow-float backdrop-blur transition-transform duration-500 hover:-translate-y-1.5"
              >
                <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-navy text-navy-foreground">
                  <v.icon className="h-5.5 w-5.5" />
                </span>
                <div>
                  <h3 className="text-lg font-bold">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{v.copy}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section data-reveal id="about" className="py-14 sm:py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 lg:grid-cols-2 lg:px-8">
          <div>
            <span className="text-xs font-semibold tracking-[0.18em] text-navy uppercase">
              About Faaner LLC
            </span>
            <h2 className="mt-4 text-3xl font-extrabold sm:text-5xl">
              A US-registered retail partner built on clear commitments
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground">
              <p>
                Faaner LLC is a registered e-commerce business based in Wyoming, USA. We purchase,
                merchandise and sell branded consumer products across leading online marketplaces and
                direct digital channels.
              </p>
              <p>
                Our team operates as a disciplined retail partner: authorized sourcing, accurate product
                content, policy-compliant pricing and dependable order volume. Brands and distributors work
                with us because our reporting is transparent and our operations are predictable.
              </p>
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              {["Wyoming registered", "Marketplace retailer", "Distributor friendly"].map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-border bg-secondary px-4 py-2 text-xs font-semibold text-secondary-foreground"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          <TiltCard className="rounded-4xl" max={7}>
            <div className="relative overflow-hidden rounded-4xl border border-border/70 bg-sky-tint p-10 shadow-lift">
              <div
                className="drift-slow pointer-events-none absolute -top-20 -right-16 h-72 w-72 rounded-full blur-3xl"
                style={{
                  background:
                    "radial-gradient(circle, color-mix(in oklab, var(--navy) 24%, transparent) 0%, transparent 70%)",
                }}
              />
              <FaanerLogo className="relative h-14 text-3xl" />
              <p className="relative mt-8 font-display text-xl leading-snug font-bold sm:text-2xl">
                “We treat every brand catalog as if it were our own — protected, priced correctly and
                presented properly.”
              </p>
              <p className="relative mt-6 text-sm text-muted-foreground">
                Faaner LLC — Retail &amp; Distribution Team
              </p>
            </div>
          </TiltCard>
        </div>
      </section>

      {/* Contact */}
      <section data-reveal id="contact" className="relative overflow-hidden py-14 sm:py-20">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-linear-to-b from-background via-sky-tint/70 to-background" />
        <div className="mx-auto grid max-w-6xl gap-12 px-5 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
          <div>
            <span className="text-xs font-semibold tracking-[0.18em] text-navy uppercase">
              Partner inquiry
            </span>
            <h2 className="mt-4 text-3xl font-extrabold sm:text-5xl">Become a Partner</h2>
            <p className="mt-5 text-muted-foreground">
              Tell us about your brand or distribution portfolio. Our team replies to qualified inquiries
              within one business day.
            </p>
            <a
              href="mailto:sales@faanerllc.com"
              className="mt-8 inline-flex items-center gap-3 rounded-2xl border border-border/70 bg-card/85 px-5 py-4 text-sm font-semibold shadow-float backdrop-blur transition-colors hover:text-navy"
            >
              <Mail className="h-4 w-4 text-navy" /> sales@faanerllc.com
            </a>
            <div className="mt-7 border-t border-border pt-5"><CompanyDetails /></div>
          </div>
          <div className="rounded-4xl border border-border/70 bg-card p-7 shadow-lift sm:p-10">
            <PartnerForm />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-14">
        <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <div>
            <FaanerLogo className="h-8 text-xl" />
            <p className="mt-4 text-sm text-muted-foreground">
              Faaner LLC — Registered in Wyoming, USA | Contact:{" "}
              <a href="mailto:sales@faanerllc.com" className="font-medium text-foreground hover:text-navy">
                sales@faanerllc.com
              </a>
            </p>
          </div>
          <nav className="flex flex-wrap gap-6 text-sm text-muted-foreground">
            <Link to="/privacy" className="hover:text-navy">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-navy">Terms of Service</Link>
            <span>© {new Date().getFullYear()} Faaner LLC</span>
          </nav>
        </div>
      </footer>
    </div>
  );
}
