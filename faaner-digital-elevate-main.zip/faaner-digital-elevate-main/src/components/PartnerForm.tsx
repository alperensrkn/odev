import { useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { inquirySchema as schema } from "@/lib/inquiry-schema";
import { submitInquiry } from "@/lib/inquiry.functions";
import { CheckCircle2, Loader2 } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
export function PartnerForm() {
  const [values, setValues] = useState({ name: "", company: "", email: "", message: "" });
  const submit = useServerFn(submitInquiry);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const [website, setWebsite] = useState("");
  const [submissionId, setSubmissionId] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const field = (key: keyof typeof values, label: string, type = "text") => (
    <label className="block" htmlFor={`inquiry-${key}`}>
      <span className="text-xs font-semibold tracking-[0.14em] text-muted-foreground uppercase">
        {label}
      </span>
      <input
        type={type}
        id={`inquiry-${key}`}
        name={key}
        required
        aria-label={label}
        maxLength={key === "email" ? 255 : key === "company" ? 120 : 100}
        aria-invalid={!!errors[key]}
        disabled={busy}
        value={values[key]}
        onChange={(e) => setValues((v) => ({ ...v, [key]: e.target.value }))}
        className="mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-all focus:border-navy focus:ring-3 focus:ring-sky-tint-strong"
      />
      {errors[key] && <span className="mt-1 block text-xs text-destructive">{errors[key]}</span>}
    </label>
  );

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) next[String(issue.path[0])] = issue.message;
      setErrors(next);
      return;
    }
    setErrors({});
    setBusy(true);
    const id = submissionId || crypto.randomUUID();
    setSubmissionId(id);
    try {
      await submit({ data: { ...parsed.data, submissionId: id, website } });
      setSuccess(true);
      setValues({ name: "", company: "", email: "", message: "" });
      setSubmissionId("");
      toast.success("Your inquiry has been received.");
    } catch (error) {
      setErrors({ submit: error instanceof Error ? error.message : "Unable to submit. Please try again." });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="grid gap-5" noValidate>
      {success && <div role="status" className="flex items-start gap-3 rounded-lg border border-border bg-sky-tint p-4 text-sm"><CheckCircle2 className="h-5 w-5 shrink-0 text-navy" /><p><strong>Thank you — your inquiry has been received.</strong><br />Our team will review your message.</p></div>}
      <label className="hidden" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} /></label>
      <div className="grid gap-5 sm:grid-cols-2">
        {field("name", "Name")}
        {field("company", "Company")}
      </div>
      {field("email", "Email", "email")}
      <label className="block" htmlFor="inquiry-message">
        <span className="text-xs font-semibold tracking-[0.14em] text-muted-foreground uppercase">
          Message
        </span>
        <textarea
          rows={5}
          name="message"
          id="inquiry-message"
          aria-label="Message"
          required
          maxLength={1000}
          disabled={busy}
          aria-invalid={!!errors["message"]}
          value={values.message}
          onChange={(e) => setValues((v) => ({ ...v, message: e.target.value }))}
          className="mt-2 w-full resize-none rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-all focus:border-navy focus:ring-3 focus:ring-sky-tint-strong"
        />
        {errors["message"] && (
          <span className="mt-1 block text-xs text-destructive">{errors["message"]}</span>
        )}
      </label>
      <p className="text-xs text-muted-foreground">By submitting, you acknowledge our <Link to="/privacy" className="underline">Privacy Policy</Link>.</p>
      {errors["submit"] && <p role="alert" className="text-sm text-destructive">{errors["submit"]}</p>}
      <Button
        disabled={busy}
        type="submit"
        className="h-auto mt-1 inline-flex w-full items-center justify-center rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-float transition-all duration-300 hover:-translate-y-0.5 hover:bg-navy sm:w-auto sm:self-start"
      >
        {busy ? <><Loader2 className="animate-spin" /> Sending…</> : "Send inquiry"}
      </Button>
    </form>
  );
}
