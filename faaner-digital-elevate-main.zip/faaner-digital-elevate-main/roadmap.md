# Site improvements
- [ ] Bundle the official logo locally.
- [ ] Add privacy and terms pages and footer links.
- [ ] Store validated inquiries and verify submission.
- [ ] Enable owner email notifications (requires verified sender domain).
- [ ] Add hero visual, tighter spacing, company details, honest wording, and scroll reveals.
- [ ] Verify mobile and desktop; apply security update.