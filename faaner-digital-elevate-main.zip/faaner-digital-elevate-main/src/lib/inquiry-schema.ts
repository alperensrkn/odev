import { z } from "zod";

export const inquirySchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  company: z.string().trim().min(1, "Company is required").max(120),
  email: z.string().trim().email("Enter a valid email").max(255),
  message: z.string().trim().min(1, "Message is required").max(1000),
});

export const inquirySubmissionSchema = inquirySchema.extend({
  submissionId: z.string().uuid(),
  website: z.string().max(200).default(""),
});