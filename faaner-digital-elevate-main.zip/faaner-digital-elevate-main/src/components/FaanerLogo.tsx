import { cn } from "@/lib/utils";
import logoMark from "@/assets/faaner-logo-mark.png";

type Props = {
  className?: string;
  animate?: boolean;
  showWordmark?: boolean;
  wordmarkClassName?: string;
};

/** Official Faaner logo bundled with the site for every domain. */
export function FaanerLogo({ className, animate = false }: Props) {
  return (
    <img
      src={logoMark}
      alt="Faaner LLC logo"
      className={cn("w-auto object-contain", animate && "logo-pop", className)}
      loading="eager"
      decoding="async"
    />
  );
}

export default FaanerLogo;
