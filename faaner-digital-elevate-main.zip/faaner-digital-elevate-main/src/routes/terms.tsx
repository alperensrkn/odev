import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/LegalPage";

export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [
    { title: "Terms of Service | Faaner LLC" },
    { name: "description", content: "Terms for using Faaner LLC’s website and making retail partnership inquiries." },
    { property: "og:title", content: "Terms of Service | Faaner LLC" },
    { property: "og:description", content: "Website and partnership inquiry terms for Faaner LLC, Wyoming, USA." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Terms,
});

function Terms() {
  return <LegalPage title="Terms of Service">
    <section><h2>1. About these terms</h2><p>These terms govern use of the Faaner LLC website. Faaner LLC is registered in Wyoming, USA. By using this website, you agree to these terms to the extent permitted by applicable law. Questions may be sent to <a href="mailto:sales@faanerllc.com">sales@faanerllc.com</a>.</p></section>
    <section><h2>2. Website purpose and partnership inquiries</h2><p>The website provides information about our e-commerce retail and distribution activities and accepts inquiries from brands and distributors. Submitting an inquiry does not create a partnership, purchase order, agency relationship, exclusivity arrangement, or binding agreement. Any business relationship requires separate agreement between the parties.</p></section>
    <section><h2>3. Products, sourcing, and transactions</h2><p>Categories and product imagery are illustrative, not a live inventory or an offer to sell a specific item. Sourcing and distribution depend on authorized supply, brand approval, product availability, applicable laws, marketplace requirements, and agreed territories. No sales volume, geographic coverage, listing approval, or commercial outcome is guaranteed.</p><p>This website does not process purchases or payments. Prices, payment terms, shipping, delivery, returns, warranties, and cancellations for an actual transaction are governed by the applicable marketplace terms or separate written agreement, together with mandatory consumer rights. Nothing here limits rights that cannot lawfully be excluded.</p></section>
    <section><h2>4. Acceptable use</h2><p>Provide accurate inquiry information and act only on behalf of a business you are authorized to represent. Do not submit unlawful material, spam, malicious code, or another person’s confidential information without authority. Do not attempt unauthorized access, interfere with the website, or misuse its forms.</p></section>
    <section><h2>5. Intellectual property</h2><p>Faaner LLC’s logo, website text, and original materials are owned by or licensed to Faaner LLC and protected by applicable law. You may view the site for personal or legitimate business evaluation. You may not reproduce our branding or imply endorsement without permission. Third-party names and marks belong to their respective owners; their appearance does not by itself establish a partnership.</p></section>
    <section><h2>6. Availability and third-party services</h2><p>We aim to keep website information accurate, but content may change and the website may occasionally be unavailable. External links and services are controlled by their respective providers and governed by their own terms and privacy policies.</p></section>
    <section><h2>7. Disclaimers and liability</h2><p>To the extent permitted by law, this informational website is provided as available without guarantees of uninterrupted access or error-free content. Faaner LLC is not liable for indirect or consequential losses arising solely from use of this website where such exclusions are lawful. These terms do not exclude liability for fraud, willful misconduct, or any liability that cannot be excluded by applicable law.</p></section>
    <section><h2>8. Privacy</h2><p>Our <a href="/privacy">Privacy Policy</a> explains how we handle information provided through the website. Do not submit sensitive personal or confidential commercial information unless necessary and appropriately authorized.</p></section>
    <section><h2>9. Governing law and updates</h2><p>These website terms are governed by the laws of Wyoming, USA, subject to mandatory protections applicable in your jurisdiction. Contact us first to discuss any website-related dispute. Separate commercial agreements may specify their own governing law and dispute process. We may revise these terms by publishing an updated version with a new effective date.</p></section>
  </LegalPage>;
}